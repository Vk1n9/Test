library(fda)
library(MASS)
library(Matrix)
library(nlme)
library(lattice)
library(car)
library(glmmTMB)

### This Function is written by Ruzong Fan, March, 2018 ###
#' Title
#'
#' @param ped ped_sim
#' @param cov cov_sim
#' @param geno gen_sim
#' @param pos pos_sim
#' @param mu_nknots 10
#' @param correlation "exponential"
#' @param order 4
#' @param beta_basis 11
#' @param geno_basis 11
#' @param base "bspline"
#'
#' @importFrom glmmTMB glmmTMB
#' @importFrom fda create.bspline.basis
#' @importFrom fda create.fourier.basis
#' @importFrom fda eval.basis
#' @importFrom MASS ginv
#' @importFrom fda inprod
#' @importFrom glmmTMB numFactor
#' @importFrom stats anova
#' @importFrom stats binomial
#
#' @return a value
#' @export
#'
#'
FLM_longi_disc_popu_fixed <- function(ped, cov, geno, pos, mu_nknots, correlation, order=4, beta_basis, geno_basis, base)
{
  #ped <- ped_sim; cov <- cov_sim; geno <- gen_sim; pos <- pos_sim; mu_nknots <- 10
  #Correlation <- "exponential"; order <- 4; beta_basis <- 11; base <- "bspline";geno_basis <- 11
  if (ncol(geno)-2 != length(pos))
  {
    return(print("Length of pos is not equal to the number of geno"))
  }

  ### Read covariate data ###
  cov <- cov[, -c(1:2)]
  cov[is.na(cov)] <- 0

  ### CREATE BASIS
  if (base ==  "bspline")
  {
    betabasis  <- create.bspline.basis(norder = order, nbasis = beta_basis)
    genobasis  <- create.bspline.basis(norder = order, nbasis = geno_basis)
  } else if (base == "fspline")
  {
    betabasis  <- create.fourier.basis(c(0,1), nbasis = beta_basis)
    genobasis  <- create.fourier.basis(c(0,1), nbasis = geno_basis)
  }

  ### Read genotype data ###
  geno <- geno[, -c(1:2)]

  #### DEALING WITH MISSING GENO
  idx.na <- is.na(geno)

  #### CASE WTIH NO MISSING GENO
  if (sum(idx.na) == 0)
  {
    dqr     <- qr(geno)
    qr_id   <- dqr$pivot[1:dqr$rank]
    geno    <- as.matrix(geno[, qr_id])
    pos     <- pos[qr_id]

    ### Normalize the region to [0,1] if needed
    if (max(pos) > 1)
    {
      pos <- (pos - min(pos)) / (max(pos) - min(pos))
    }

    B <- eval.basis(pos, genobasis)

    to_mul <- ginv(t(B) %*% B) %*% t(B)
    U      <- as.matrix(geno) %*% t( to_mul )
    J      <- inprod(genobasis, betabasis)
    UJ     <- matrix( U %*% J, ncol = ncol(J) )
  }

  #### CASE WITH MISSING GENO
  if (sum(idx.na)>0)
  {
    ### Normalize the region to [0,1] if needed
    if (max(pos) > 1)
    {
      pos <- (pos - min(pos)) / (max(pos) - min(pos))
    }

    B  <- eval.basis(pos, genobasis)
    J  <- inprod(genobasis, betabasis)
    UJ <- NULL

    for (i in 1:nrow(geno))
    {
      idx <- which(is.na(geno[i,]))
      if (length(idx)== ncol(geno))
      {
        tmp <-  rep(NA, ncol(B))
      }else if (length(idx) ==  0)
      {
        gi  <- geno[i,]
        Bi  <- B
        to_mul <- ginv(t(Bi) %*% Bi) %*% t(Bi)
        gi_m   <- matrix(gi,nrow = 1)
        U      <- unlist(gi_m) %*% t( to_mul )
        tmp    <-  U %*% J
      }else
      {
        gi  <- geno[i, -idx]
        Bi  <- B[-idx,]
        to_mul <- ginv(t(Bi) %*% Bi) %*% t(Bi)
        gi_m   <- matrix(gi,nrow = 1)
        U      <- unlist(gi_m) %*% t( to_mul )
        tmp    <-  U %*% J
      }
      UJ <- rbind(UJ, tmp)
    }
  }

  #### SET TRAIT TO NA IF WHOLE GENO IS MISSING, SO THAT MODEL WILL USE DATA WITHOUT SUBJECT WITH WHOLE GENO MISSING
  if (sum(is.na(UJ))>0)
  {
    tmp1 <- is.na(UJ)
    tmp2 <- apply(tmp1, 1, sum)
    ped[tmp2>0, "event"] <- NA
  }

  ###
  idx   <- is.na(ped[, "event"])
  trait <- ped[!idx, "event"]
  cov   <- data.frame(cov)[!idx,]
  ped   <- ped[!idx, ]
  UJ    <- UJ[!idx,]
  id    <- ped[, "ped"]
  time  <- ped[, "time"]
  n_t   <- length(time)
  group <- rep(1,n_t)
  time2 <- numFactor(time)

  ### Make sure UJ has full rank of bbasis or fbasis ###
  UJdqr   <- qr(UJ)
  UJindex <- UJdqr$pivot[1:UJdqr$rank]
  UJ      <- UJ[, UJindex]

  ##Defining matrix terms for the mean ###
  t_knot    <- seq(min(time, na.rm = T), max(time, na.rm = T),length = mu_nknots + 2)  #check this
  knot_mean <- t_knot[-c(1, length(t_knot))]
  z1        <- outer(time, knot_mean, "-")
  z2        <- z1*(z1>0)
  z_mean    <- cbind(time, z2)

  ###
  pval <- list()

  if (correlation == "none")
  {
    fit_cov      <- glmmTMB(trait ~ 1 + as.matrix(cov)      + (time + 0 | id), family = binomial)
    fit_cov_geno <- glmmTMB(trait ~ 1 + as.matrix(cov) + UJ + (time + 0 | id), family = binomial)

    #treat mu(t) as fixed
    fit_cov_fix      <- glmmTMB(trait ~ as.matrix(cov) + z_mean      + (time + 0 | id), family = binomial)
    fit_cov_fix_geno <- glmmTMB(trait ~ as.matrix(cov) + z_mean + UJ + (time + 0 | id), family = binomial)

    #treat mu(t) as random
    #fit_cov_mix      <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group)      + (time + 0 | id), family = binomial)
    #fit_cov_mix_geno <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group) + UJ + (time + 0 | id), family = binomial)
  } else if (correlation == "ou")
  {
    fit_cov      <- glmmTMB(trait ~ 1 + as.matrix(cov)      + ou(time2 + 0 | id), family = binomial)
    fit_cov_geno <- glmmTMB(trait ~ 1 + as.matrix(cov) + UJ + ou(time2 + 0 | id), family = binomial)

    #treat mu(t) as fixed
    fit_cov_fix      <- glmmTMB(trait ~ as.matrix(cov) + z_mean      + ou(time2 + 0 | id), family = binomial)
    fit_cov_fix_geno <- glmmTMB(trait ~ as.matrix(cov) + z_mean + UJ + ou(time2 + 0 | id), family = binomial)

    #treat mu(t) as random
    #fit_cov_mix      <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group)      + ou(time2 + 0 | id), family = binomial)
    #fit_cov_mix_geno <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group) + UJ + ou(time2 + 0 | id), family = binomial)
  } else if (correlation == "gauss")
  {
    fit_cov      <- glmmTMB(trait ~ 1 + as.matrix(cov)      + gau(time2 + 0 | id), family = binomial, dispformula=~0)
    fit_cov_geno <- glmmTMB(trait ~ 1 + as.matrix(cov) + UJ + gau(time2 + 0 | id), family = binomial, dispformula=~0)

    #treat mu(t) as fixed
    fit_cov_fix      <- glmmTMB(trait ~ as.matrix(cov) + z_mean      + gau(time2 + 0 | id), family = binomial, dispformula=~0)
    fit_cov_fix_geno <- glmmTMB(trait ~ as.matrix(cov) + z_mean + UJ + gau(time2 + 0 | id), family = binomial, dispformula=~0)

    #treat mu(t) as random
    #fit_cov_mix      <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group)      + gau(time2 + 0 | id), family = binomial, dispformula=~0)
    #fit_cov_mix_geno <- glmmTMB(trait ~ as.matrix(cov) + (z_mean + 0 | group) + UJ + gau(time2 + 0 | id), family = binomial, dispformula=~0)
  }

  ###
  tryCatch(
    error = function(cnd)
    {
      pval$fit_cov_geno <- NA
    },
    pval$fit_cov_geno   <- anova(fit_cov, fit_cov_geno)[2,8])

  tryCatch(
    error = function(cnd)
    {
      pval$fit_cov_mu_fixed_geno <- NA
    },
    pval$fit_cov_mu_fixed_geno <- anova(fit_cov_fix, fit_cov_fix_geno)[2,8])

  #tryCatch(
  #   error = function(cnd)
  #      {
  #      pval$fit_cov_mu_mixed_geno <- NA
  #     },
  #      pval$fit_cov_mu_mixed_geno <- anova(fit_cov_mix, fit_cov_mix_geno)[2,8])

  pval$fit_cov_mu_mixed_geno = 1
  pval
}
